from flask import Flask, render_template, request, redirect

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/cadastrar_aluno", methods=['POST'])
def cadastrar_aluno():
    nome_aluno = request.form["nome_aluno"]
    notas = [
        float(request.form["nota1"]),
        float(request.form["nota2"]),
        float(request.form["nota3"]),
        float(request.form["nota4"])
    ]
    media = sum(notas) / len(notas)

    caminho_arquivo = 'alunos.txt'

    with open(caminho_arquivo, 'a') as arquivo:
        arquivo.write(f"{nome_aluno};{media:.2f}\n")

    return redirect("/consulta")

@app.route("/consulta")
def consultar_alunos():
    alunos = []
    caminho_arquivo = 'alunos.txt'

    try:
        with open(caminho_arquivo, 'r') as arquivo:
            for aluno in arquivo:
                item = aluno.strip().split(';')
                alunos.append({
                    'nome': item[0],
                    'media': item[1]
                })
    except FileNotFoundError:
        pass  

    return render_template("consulta_alunos.html", alunos=alunos)

@app.route("/deletar_aluno", methods=['POST'])
def deletar_aluno():
    nome_aluno = request.form["nome_aluno"]
    caminho_arquivo = 'alunos.txt'

    
    alunos = []
    try:
        with open(caminho_arquivo, 'r') as arquivo:
            for aluno in arquivo:
                item = aluno.strip().split(';')
                if item[0] != nome_aluno:  
                    alunos.append(aluno.strip())
    except FileNotFoundError:
        pass  

    
    with open(caminho_arquivo, 'w') as arquivo:
        for aluno in alunos:
            arquivo.write(f"{aluno}\n")

    return redirect("/consulta")

if __name__ == "__main__":
    app.run(host='127.0.0.1', port=80, debug=True)